Estructura de las carpetas

Las carpetas en las cual el nombre incluye ".2" o "_v2" consisten en la versión mejorada de las prácticas anteriores con las mejoras comentadas en el informe.
Las nuevas versiones de las prácticas 3 y 4 incluyen integrada la subida y descarga de ficheros mediante SOAP y REST.
La carpeta "WebAppClient3.2_Remoto" incluye lo mismo que la carpeta sin Remoto en el nombre pero esta contiene los cambios necesarios en la configuración del WSDL para que esta práctica funcione de forma remota en su uso.
